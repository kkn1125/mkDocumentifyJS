const Documentify = (function(){ // 즉시실행 후 내부 함수 숨기는 효과

    function Controller(){ // 이벤트 조작
        let moduleModel = null;
        let uiElem = null;
        let obj = null;
        let uploaded = null;

        this.init = function(model, ui, object){
            moduleModel = model;
            uiElem = ui;
            obj = object;

            // uiElem.file.addEventListener('change', this.fileUploadHandler);
            window.addEventListener('load', this.getJSFile);
        }

        this.getJSFile = function(){
            let xhr = new XMLHttpRequest();

            xhr.addEventListener('readystatechange', (ev) => {
                if (xhr.readyState === xhr.DONE) {
                    if (xhr.status === 200 || xhr.status === 201) {
                        moduleModel.parseComments(xhr.responseText);
                    }
                }
            });

            xhr.open('get', obj.url, false);
            xhr.send();
        }
    }

    function Model(){ // 객체 조작
        let moduleView = null;
        let parsingDataList = [];
        // let commentForm = c => {
        //     return {
        //         name: null,
        //         type: null,
        //         desc: null,
        //     }
        // };

        this.init = function(view){
            moduleView = view;
        }

        this.parseComments = function(comments){
            let regex = /\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm;
            let parseData = comments.match(regex);
            parseData.forEach(p=>
                document.body.innerHTML += p+'<br>'
                )
        }

    }

    function View(){
        let uiElem = null;

        this.init = function(ui){
            uiElem = ui;
        }
    }

    return {
        init: function(object){
            const file = document.getElementById('file');

            const ui = {
                file
            }

            const view = new View();
            const model = new Model();
            const controller = new Controller();

            view.init(ui);
            model.init(view);
            controller.init(model, ui, object);
        }
    }
})();